/*******************************************************************/
/* Course: Advanced Programming for Physics (2019-2020)            */
/*******************************************************************/
/* The program solves the second degree equation                   */
/* i.e. it solves the following equation: ax^2 + bx + c = 0        */
/*                                                                 */
/* Compile the code using the command:                             */
/* $ gcc -Wall equation.c -o equation -lm                          */
/*                                                                 */
/* Run the program using the command:                              */
/* $ ./equation                                                    */
/*                                                                 */
/* Author: David Goz - david.goz@inaf.it                           */
/*******************************************************************/

#include <stdio.h>
#include <math.h>

#define SMALL 1.e-6

int main()
{
  /* coefficients */
  float a, b, c;

  /* get coefficients from stdin */
  printf("\n\t Enter the coefficients a, b, c\n");
  scanf("%f %f %f", &a, &b, &c);

  /* discriminant */
  const float delta = (b * b) - (4.0 * a * c);

  if (delta < 0)
    {
      /* no real solutions */
      printf("\n\t No real solutions for (%f)x^2 + (%f)x + (%f) = 0\n\n",
	     a, b, c);
    }
  else
    {
      /* delta == 0 */
      if (fabs(delta) < SMALL)
	{
	  printf("\n\t The solution of (%f)x^2 + (%f)x + (%f) = 0 are x1 = x2 = %f \n\n",
		 a, b, c, -b / (2.0 * a));
	}
      /* delta > 0 */
      else
	{
	  printf("\n\t The solution of (%f)x^2 + (%f)x + (%f) = 0 are x1 = %f and x2 = %f \n\n",
		 a, b, c, (-b - sqrt(delta)) / (2.0 * a), (-b + sqrt(delta)) / (2.0 * a));
	}
    }

  return 0;
}
