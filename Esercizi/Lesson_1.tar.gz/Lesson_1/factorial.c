/*******************************************************************/
/* Course: Advanced Programming for Physics (2019-2020)            */
/*******************************************************************/
/* The program finds the factorial of a positive integer number    */
/* i.e. given N it calculates N! = N*(N-1)*(N-2)*...*2             */
/*                                                                 */
/* Compile the code using the command:                             */
/* $ gcc -Wall factorial.c -o factorial                            */
/*                                                                 */
/* Run the program using the command:                              */
/* $ ./factorial                                                   */
/*                                                                 */
/* Author: David Goz - david.goz@inaf.it                           */
/*******************************************************************/

#include <stdio.h>

#define BIG 12

int main()
{
  /* integer number */
  int N;

  /* get the number from stdin */
  printf("\n\t Enter an integer number\n");
  scanf("%d", &N);

  if (N < 0)
    printf("\n\t Error! Factorial of a negative number doesn't exist.\n\n");
  else if (N > BIG)
    printf("\n\t Error! Integer overflow\n\n");
  else
    {
      int factorial = 1;

      for (int i=N ; i>1 ; i--)
	factorial *= i;

      printf("\n\t The factorial of N = %d is %d\n\n",
	     N, factorial);
    }
  
  return 0;
}
