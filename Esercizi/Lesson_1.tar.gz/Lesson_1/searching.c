/*******************************************************************/
/* Course: Advanced Programming for Physics (2019-2020)            */
/*******************************************************************/
/* A and B are two vectors containing particle's IDs.              */
/* The program finds the index of matching IDs of A in B           */
/* (index = -1 for particles not found)                            */
/*                                                                 */
/* Compile the code using the command:                             */
/* $ gcc -Wall searching.c -o searching                            */
/*                                                                 */
/* Run the program using the command:                              */
/* $ ./searching                                                   */
/*                                                                 */
/* Author: David Goz - david.goz@inaf.it                           */
/*******************************************************************/

#include <stdio.h>

#define N 10

#define MyPrintf(STRING, X) {printf("\n\t %s = [ ", STRING);  \
                             for (int i=0 ; i<N ; i++)	      \
			       printf("%d ", X[i]);	      \
			     printf("]\n");}

int main()
{
  const int A[N] = {10, 35, 8, 42, 6,  19, 33, 49, 20, 4};
  const int B[N] = {1,  19, 4, 67, 99, 8,  10, 32, 7,  42};
  int C[N];

  /* loop over A */
  for (int index_A=0 ; index_A<N ; index_A++)
    {
      /* particle not found */
      C[index_A] = -1;

      /* loop over B */
      for (int index_B=0 ; index_B<N ; index_B++)
	{
	  /* matching */
	  if (A[index_A] == B[index_B])
	    {
	      C[index_A] = index_B;
	      break;
	    }
	} /* loop over B */
    } /* loop over A */

  MyPrintf("A", A);
  MyPrintf("B", B);
  MyPrintf("C", C);
  
  return 0;
}
