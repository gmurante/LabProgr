
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

typedef unsigned int uint;


uint welcome( int );
void check_args( int, char ** );
